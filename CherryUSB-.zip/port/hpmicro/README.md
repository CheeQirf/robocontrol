# Note

## Support Chip List

- HPM all series (HPMicro + EHCI)
