# Note

## Support Chip List

- BL616/BL808
