# Note

## Support Chip List

- M032 Series
- M480 Series

