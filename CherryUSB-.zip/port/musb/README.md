# Note

## Support Chip List

### Eastsoft

- ES32F3xx

### TI

- MSP432E4x

### Bekencorp

- BK7256/BK7258

### AllwinnerTech

- F1Cxxx, F2Cxxx
